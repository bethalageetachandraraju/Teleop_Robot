^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package robot_pose_publisher
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.4 (2016-02-18)
------------------
* Update README.md
* Update package.xml
* fixed dox file
* fixed readme
* travis edit
* Contributors: David Kent, Russell Toris

0.2.3 (2014-04-03)
------------------
* cleanup for release
* travis fix
* travis test
* gitignore cleanup
* Dry branch cleanup
* Contributors: Russell Toris

0.2.2 (2013-04-09)
------------------
* Merge pull request `#3 <https://github.com/WPI-RAIL/robot_pose_publisher/issues/3>`_ from jihoonl/groovy-devel
  searches private node handle to get parameter
* searches private node handle to get parameter
* Merge pull request `#2 <https://github.com/WPI-RAIL/robot_pose_publisher/issues/2>`_ from jihoonl/groovy-devel
  parameter setting. pose -> posestamped
* is_stamped param added
* parameter setting. pose -> posestamped
* Contributors: Jihoon Lee, Russell Toris

0.2.1 (2013-01-24)
------------------
* Merge pull request `#1 <https://github.com/WPI-RAIL/robot_pose_publisher/issues/1>`_ from rctoris/groovy-devel
  error messages removed to cleanup output
* 0.2.1 released
* error messages removed to cleanup output
* Contributors: Russell Toris

0.2.0 (2013-01-10)
------------------
* install added
* gitignore cleaned
* catkinized package
* .gitignore updated with eclipse settings
* .gitignore updated with eclipse settings
* new release build
* initial import
* Contributors: Russell Toris
